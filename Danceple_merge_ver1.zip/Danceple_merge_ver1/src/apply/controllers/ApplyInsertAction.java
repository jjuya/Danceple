package apply.controllers;

public class ApplyInsertAction {
	
	

}
